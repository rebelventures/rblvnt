const allowed=new Set(['https://rblvnt.com','https://www.rblvnt.com','https://rblvnt-workshop.heartyamber10.chatgpt.site']);
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 let origin;try{origin=new URL(sender.url).origin}catch{return false}
 if(message?.type==='rblvnt-submit'&&allowed.has(origin)&&sender.frameId===0){
  if(typeof message.prompt!=='string'||!message.prompt.trim()||message.prompt.length>8000){reply({ok:false});return false}
  (async()=>{const nonce=crypto.randomUUID(),key='handoff:'+nonce;await chrome.storage.session.set({[key]:{prompt:message.prompt,created:Date.now(),tab:null}});let tab;try{tab=await chrome.tabs.create({url:'https://chatgpt.com/#rblvnt-submit='+nonce});await chrome.storage.session.set({[key]:{prompt:message.prompt,created:Date.now(),tab:tab.id}});reply({ok:true})}catch{await chrome.storage.session.remove(key);reply({ok:false})}})();return true;
 }
 if(message?.type==='rblvnt-consume'&&origin==='https://chatgpt.com'&&sender.frameId===0&&typeof message.nonce==='string'&&/^[0-9a-f-]{36}$/.test(message.nonce)){
  (async()=>{const key='handoff:'+message.nonce,item=(await chrome.storage.session.get(key))[key];if(!item||Date.now()-item.created>300000){if(item)await chrome.storage.session.remove(key);reply({ok:false});return}if(item.tab!==sender.tab?.id){reply({ok:false,retry:item.tab===null});return}await chrome.storage.session.remove(key);reply({ok:true,prompt:item.prompt})})();return true;
 }
 return false;
});
chrome.tabs.onRemoved.addListener(async tabId=>{const all=await chrome.storage.session.get(null);for(const [key,value]of Object.entries(all))if(key.startsWith('handoff:')&&(value.tab===tabId||Date.now()-value.created>300000))await chrome.storage.session.remove(key)});
