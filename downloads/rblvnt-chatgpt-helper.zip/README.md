# rblvnt ChatGPT handoff

This optional, locally installed Edge/Chrome extension opens a new ChatGPT tab and submits a question only after you submit the rblvnt ChatGPT form. It is not installed automatically.

Install:
1. Download and extract the ZIP from the start page's Connections page.
2. Open `edge://extensions` (or `chrome://extensions`).
3. Turn on Developer mode and choose Load unpacked.
4. Select the extracted folder containing manifest.json, then reload your start page.
5. “Auto-submit ready” appears below the ChatGPT box.

It uses the normal ChatGPT session already in your browser. Sign in to ChatGPT first. If ChatGPT changes its composer or send button, automation may stop; your typed question is never sent unless the extension confirms that the composer matches it exactly. Typing or clicking inside the new ChatGPT tab cancels automation. It does not overwrite an existing draft or send within an existing conversation.

Permissions: content scripts on ChatGPT and the three explicitly listed rblvnt origins; browser session storage. It does not request cookies, browsing history, debugger, broad host access, X access, or YouTube access. A pending prompt is held in extension session storage, tied to one newly created tab, consumed once, and expires after five minutes. There is no analytics or external server. Remove the extension to stop using it.

Validation: syntax and message-boundary checks passed. Live ChatGPT submission has not been tested in the user's logged-in browser. Installing this local extension requires the user's action and grants it access to ChatGPT page content.
